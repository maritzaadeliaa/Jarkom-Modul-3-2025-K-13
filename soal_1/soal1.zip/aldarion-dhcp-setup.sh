#!/bin/bash

# Konfigurasi IP Address
ip addr add 10.70.4.10/24 dev eth0
ip route replace default via 10.70.4.1
echo "nameserver 192.168.122.1" > /etc/resolv.conf

# Testing koneksi
ping -c3 10.70.4.1
ping -c3 8.8.8.8
ping -c3 google.com

# Install DHCP Server
apt update
apt install isc-dhcp-server -y

# Konfigurasi interface DHCP
cat > /etc/default/isc-dhcp-server << 'EOF'
INTERFACESv4="eth0"
INTERFACESv6=""
EOF

# Konfigurasi dhcpd.conf
cat > /etc/dhcp/dhcpd.conf << 'EOF'
ddns-update-style none;
authoritative;

default-lease-time 600;
max-lease-time 7200;

subnet 10.70.1.0 netmask 255.255.255.0 {
    range 10.70.1.20 10.70.1.99;
    range 10.70.1.150 10.70.1.169;
    option routers 10.70.1.1;
    option domain-name-servers 10.70.5.2;
    default-lease-time 1800;
    max-lease-time 3600;
}

subnet 10.70.2.0 netmask 255.255.255.0 {
    range 10.70.2.30 10.70.2.50;
    range 10.70.2.155 10.70.2.185;
    option routers 10.70.2.1;
    option domain-name-servers 10.70.5.2;
    default-lease-time 600;
    max-lease-time 3600;
}

subnet 10.70.4.0 netmask 255.255.255.0 {
    range 10.70.4.30 10.70.4.50;
    option routers 10.70.4.1;
    option broadcast-address 10.70.4.255;
    option domain-name-servers 8.8.8.8;
}

subnet 10.70.3.0 netmask 255.255.255.0 { }
subnet 10.70.5.0 netmask 255.255.255.0 { }
EOF

# Start DHCP Service
service isc-dhcp-server start
service isc-dhcp-server restart
service isc-dhcp-server status

grep -i INTERFACESv4 /etc/default/isc-dhcp-server

# Testing manual
pkill dhcpd
dhcpd -4 -d -cf /etc/dhcp/dhcpd.conf eth0