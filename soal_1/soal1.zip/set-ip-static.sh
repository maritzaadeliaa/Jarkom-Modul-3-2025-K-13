# 1) Set IP sementara (statik) sesuai subnet
ip addr add 10.70.<NET>.<HOST>/24 dev eth0

# 2) Set default route ke Durin (gateway subnet)
ip route add default via 10.70.<NET>.1 dev eth0

# 3) (Sementara) pasang DNS publik agar apt bisa resolve
echo "nameserver 8.8.8.8" > /etc/resolv.conf

# 4) Cek konektivitas
ping -c3 8.8.8.8
ping -c3 google.com
